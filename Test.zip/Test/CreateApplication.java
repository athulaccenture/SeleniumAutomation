package Test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreateApplication {

	public static void main(String[] args) throws Exception {
		ChromeDriver driver= new ChromeDriver();
	    driver.get("https://login.veevavault.com/auth/login");
	    driver.manage().window().maximize();
		driver.findElementById("j_username").sendKeys("sushma.lingaraju@sb-sanofi.com");
		driver.findElementById("j_password").sendKeys("SH7581sh*");
		driver.findElement(By.className("vv_button_text")).click();
		Utility.screenshot(driver, "Login");
		driver.findElementByName("applications__c").click();
		driver.findElement(By.linkText("Applications")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"body\"]/div/div/div[1]/div/div/div[2]/div[3]/div/div[1]/div/div[1]/button/span")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementById("name__v").sendKeys("12345");
		driver.findElementByXPath("//*[@id=\"application_type__rim\"]/div[1]/input").click();
		driver.findElementByLinkText("Other").click();
		driver.findElementByXPath("//*[@id=\"region__v\"]/div[1]/input").click();
		driver.findElementByLinkText("Asia").click();
		driver.findElementByXPath("//*[@id=\"body\"]/div/div/div[1]/div/div[2]/div[2]/a[1]/span").click();
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		Utility.screenshot(driver, "Saved Application");
		String s= driver.findElementById("name__v").getAttribute("value");
		System.out.println("Application Number=" + s);
		driver.findElementByName("applications__c").click();
		driver.findElement(By.linkText("Applications")).click();
						
		String sFilePath = "C:\\Users\\athul.ks\\Downloads\\selenium-java-3.0.1\\Test1.xls";
		   try {
		     File file = new File(sFilePath);
		     FileWriter fw = new FileWriter(file.getAbsoluteFile());
		     BufferedWriter bw = new BufferedWriter(fw);
		     bw.write(s);
		     bw.close();
		     System.out.println("Data is Successfully written");
		     driver.quit();
		     }
		   
		   catch (IOException e) {
		     e.printStackTrace();
		    }
	
	}

}
