package Test;

import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel {

	@SuppressWarnings("resource")
	public static void main(String[] args) throws Exception{
		
		File src= new File("C:\\Users\\athul.ks\\Downloads\\selenium-java-3.0.1\\Input.xlsx");
		FileInputStream fis= new FileInputStream(src);
		XSSFWorkbook wb=new XSSFWorkbook(fis);
		XSSFSheet sheet1= wb.getSheetAt(0);
		int rowcount=sheet1.getLastRowNum()+1;
		System.out.println("Number of rows "+rowcount);
		for (int i=0; i<rowcount; i++)
		{
			for (int j=0; j<2; j++)
			{
				String data0=sheet1.getRow(i).getCell(j).getStringCellValue();
				System.out.println("Data in Excel is "+data0);
			}
	
	}
		
	}

}
