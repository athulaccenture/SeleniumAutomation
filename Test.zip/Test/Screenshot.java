package Test;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Screenshot {

	public static void main(String[] args) throws Exception {
		ChromeDriver driver= new ChromeDriver();
	    driver.get("https://login.veevavault.com/auth/login");
	    driver.manage().window().maximize();
		driver.findElementById("j_username").sendKeys("sushma.lingaraju@sb-sanofi.co");
		driver.findElementById("j_password").sendKeys("SH7581sh*");
		driver.findElement(By.className("vv_button_text")).click();
		//File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //FileUtils.copyFile(src, new File("C:/Users/athul.ks/Downloads/selenium-java-3.0.1/Vault.jpg"));
        //driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        //System.out.println("Screenshot Taken");
        Utility.screenshot(driver, "Error");
		driver.quit();
	}

}
