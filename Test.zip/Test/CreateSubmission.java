package Test;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class CreateSubmission {

	public static void main(String[] args) {
		ChromeDriver driver= new ChromeDriver();
	    driver.get("https://login.veevavault.com/auth/login");
		driver.findElementById("j_username").sendKeys("sushma.lingaraju@sb-sanofi.com");
		driver.findElementById("j_password").sendKeys("SH7581sh*");
		driver.findElement(By.className("vv_button_text")).click();
		driver.findElementByName("applications__c").click();
		driver.findElement(By.linkText("Applications")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//*[@id=\"body\"]/div/div/div[1]/div/div/div[2]/div[3]/div/div[1]/div/div[1]/button/span")).click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementById("name__v").sendKeys("12345");
		driver.findElementByXPath("//*[@id=\"application_type__rim\"]/div[1]/input").click();
		driver.findElementByLinkText("Other").click();
		driver.findElementByXPath("//*[@id=\"region__v\"]/div[1]/input").click();
		driver.findElementByLinkText("Asia").click();
		driver.findElementByXPath("//*[@id=\"body\"]/div/div/div[1]/div/div[2]/div[2]/a[1]/span").click();
        driver.findElementByXPath("//*[@id=\"plSection_2\"]/div[1]/div[1]/a/span").click(); 
        driver.findElementByXPath("//*[@id=\"name__v\"]").sendKeys("0003");
        driver.findElementByXPath("//*[@id=\"doss_id__c\"]").sendKeys("123456");
        driver.findElementByXPath("//*[@id=\"submission_type__rim\"]/div[1]/input").click();
        driver.findElementByLinkText("Extension").click();
        driver.findElementByXPath("//*[@id=\"body\"]/div/div/div[1]/div/div[2]/div[2]/a[1]/span").click();
        String s= driver.findElementByXPath("//*[@id=\"name__v\"]").getAttribute("value");
		System.out.println("Sequence Number=" + s);
		  String sFilePath = "C:\\Users\\athul.ks\\Downloads\\selenium-java-3.0.1\\Test2.xls";
		   try {
		     File file = new File(sFilePath);
		     FileWriter fw = new FileWriter(file.getAbsoluteFile());
		     BufferedWriter bw = new BufferedWriter(fw);
		     bw.write(s);
		     bw.close();
		     System.out.println("Data is Successfully written");
		     }
		   
		   catch (IOException e) {
		     e.printStackTrace();
		    }

	}

}
