package Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class Reports {

	public static void main(String[] args) {
		
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://login.veevavault.com/auth/login");
	    driver.manage().window().maximize();
		driver.findElementById("j_username").sendKeys("athul.ks@sb-sanofi.com");
		driver.findElementById("j_password").sendKeys("Nano6543@");
		driver.findElement(By.className("vv_button_text")).click();
		driver.findElementByXPath("//*[@id=\"VaultTopNavTabGroup\"]/span/span[1]/a[6]/span").click(); 
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElementByCssSelector("span.reportName.vv_doc_title_name").click();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		
	}

}
