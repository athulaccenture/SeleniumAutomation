package Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImportDocs {

	public static void main(String[] args) {
		
		ChromeDriver driver= new ChromeDriver();
		driver.get("https://login.veevavault.com/auth/login");
	    driver.manage().window().maximize();
		driver.findElementById("j_username").sendKeys("athul.ks@sb-sanofi.com");
		driver.findElementById("j_password").sendKeys("Nano6543@");
		driver.findElement(By.className("vv_button_text")).click();
		driver.findElementByXPath("//*[@id=\"navigationinbox_upload_buttons\"]/a/i[2]").click();
		driver.findElementByLinkText("Upload").click();
		driver.findElementByXPath("//*[@id=\"inboxFileChooserHTML5\"]").click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);

	}

}
