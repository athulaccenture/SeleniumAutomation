package Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

public class Browser {

	public static void main(String[] args) {
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.findElementById("lst-ib").sendKeys("Sachin");
		driver.findElementByTagName("svg").click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.findElementByXPath("//*[@id=\"rso\"]/div[2]/div/div/h3/a").click();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.quit();

	}

}
