package Test;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Utility {

	
	public static void screenshot (WebDriver driver, String screenshotName) throws Exception
	
	{
		File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        FileUtils.copyFile(src, new File("C:/Users/athul.ks/Downloads/selenium-java-3.0.1/"+screenshotName+".jpg"));
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        System.out.println("Screenshot Taken");
		
	}
}
