package Web;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.accenture.omnichannelframework.api.Logger;
import com.accenture.omnichannelframework.api.MethodDataStore;
import com.accenture.omnichannelframework.api.OmnichannelFramework;

import adapters.desktop.driver.SeleniumAdapter;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;

public class loginveeva {
	WebDriver driver;
	WebDriverWait wait;
	private static final Logger LOGGER = OmnichannelFramework.getLogger();
	MethodDataStore methodDataStore;
	
	@BeforeClass
	public void setUp() {
		driver = (WebDriver) OmnichannelFramework.getInstanceFromAdapter(SeleniumAdapter.ID);
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		wait = new WebDriverWait(driver, 30);
		methodDataStore = OmnichannelFramework.getMethodDataStore();
	}

	@Test
	@Parameters({ "VeevaURL" })
	public void launch(@Optional("https://login.veevavault.com/") String VeevaURL) {
		driver.get(VeevaURL);
	}

	@Test
	@Parameters({ "Username", "Password" })
	public void login(@Optional("smitha.suresh.desai@sb-sanofi.com") String Username,
			@Optional("Smitha@25") String Password) throws AWTException {

		try {
			driver.findElement(By.id("j_username")).sendKeys(Username);
			driver.findElement(By.id(methodDataStore.getValue("passwordFieldXpath"))).sendKeys(Password);
			driver.findElement(By.className("vv_button_text")).click();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='userMenu']")));
					
		
			String User = driver.findElement(By.xpath("//*[@id='userMenu']")).getText();
			System.out.println("The user " + User + " is Logged in");
			LOGGER.info("The user " + User + " is Logged in");
			Shot.seleniumSaveScreenshot(driver, "VerifyLogin.png");

			// System.out.println("login successful");
		} catch (Exception e) {
			System.err.println("wrong credentials");
			e.printStackTrace();
		}
	}
	

	  //SUBMISSIONS
	   
	   @Test
	   @Parameters({"seqName" , "legacySysId"})
	   
	   public void submissions(@Optional("12345")String seqName,@Optional("a123")String legacySysId) {
	  
	  
	  driver.findElement(By.name("applications__c")).click();
	  driver.findElement(By.linkText("Submissions")).click();
	  driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
	  driver.findElement(By.xpath("//*[@class='vv_listview_component']//descendant::button[@class='vv_button CreateObject vv_primary']")).click(); 
	  driver.manage().timeouts().implicitlyWait(25,TimeUnit.SECONDS);
	  driver.findElement(By.id("name__v")).sendKeys(seqName);
	  driver.findElement(By.id("doss_id__c")).sendKeys(legacySysId);
	  driver.findElement(By.xpath(
	  "//*[@id='application__v']")).click();
	  driver.findElement(By.linkText("12345")).click();
	  driver.findElement(By.xpath("//*[@id='submission_type__rim']")).click();
	  driver.findElement(By.linkText("Annual Report")).click();
	 driver.findElement(By.xpath(
	  "//*[@id=\"body\"]/div/div/div[1]/div/div[2]/div[2]/a[1]/span")).click();
	 driver.manage().timeouts().implicitlyWait(500,
	  TimeUnit.SECONDS);
	   }
	  
	  
	   
	  //REPORT SELECTION
	  
	  @Test
	  public void reportSelection()
	  {
	   
	  driver.findElement(By.name("reports__v")).click();
	  driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
	  //driver.findElement(By.cssSelector("span.reportName.vv_doc_title_name")).click();
	  driver.findElement(By.xpath("//*[@id=\"body\"]/div/div/div[1]/div[2]/div[3]/div/div[1]/div/div[2]/div[1]/a/span")).click(); 
	  //driver.findElement(By.xpath("//*[@id=\"body\"]/div/div/div[1]/div[2]/div[3]/div/div[2]/div/div[2]/div[1]/a/span")).click(); 
	 
	  }
	 
	// APPLICATIONS
	

	@Test
	public void createApplication() throws AWTException {
		driver.findElement(By.name("applications__c")).click();
		driver.findElement(By.linkText("Applications")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		driver.findElement(
				By.xpath("//*[@id=\"body\"]/div/div/div[1]/div/div/div[2]/div[3]/div/div[1]/div/div[1]/button/span"))
				.click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		driver.findElement(By.id("name__v")).sendKeys("12345");
		driver.findElement(By.xpath("//*[@id=\"region__v\"]/div[1]/input")).click();
		driver.findElement(By.linkText("Asia")).click();
		driver.findElement(By.xpath("//*[@id=\"application_type__rim\"]/div[1]/input")).click();
		driver.findElement(By.linkText("Other")).click();
		driver.findElement(By.xpath("//*[@id=\"body\"]/div/div/div[1]/div/div[2]/div[2]/a[1]/span")).click();
		
		
		//List gghh = driver.findElements(By.xpath("//td[@class='vv_gridview_cell selectable  gridCell']"));
		 
	}
	 
	// Upload
	@Test
	public void upload() throws AWTException {

		driver.findElement(By.xpath("//*[@id=\"navigationinbox_upload_buttons\"]/a/span")).click();
		driver.findElement(By.linkText("Upload")).click();

		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);
		driver.findElement(By.id("inboxFileChooserHTML5")).click();
		driver.manage().timeouts().implicitlyWait(25, TimeUnit.SECONDS);

		StringSelection s = new StringSelection("C:\\selenium\\Request form for Issue of Keys");
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(s, null);
		Robot robot = new Robot();
		robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
		robot.keyRelease(java.awt.event.KeyEvent.VK_ENTER);
		robot.keyPress(java.awt.event.KeyEvent.VK_CONTROL);
		robot.keyPress(java.awt.event.KeyEvent.VK_V);
		robot.keyRelease(java.awt.event.KeyEvent.VK_CONTROL);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		robot.keyPress(java.awt.event.KeyEvent.VK_ENTER);
		driver.manage().timeouts().implicitlyWait(550, TimeUnit.SECONDS);

		driver.findElement(
				By.xpath("//*[@id=\"inboxUploadPageContent\"]/div[1]/div[2]/div[2]/div/div[1]/div/div[3]/button/span"))
				.click();
		driver.findElement(By.id("uploadTypeSelect")).sendKeys("Regulatory");
		driver.findElement(By.id("uploadSubTypeSelect")).sendKeys("Health Authority Communication");
		driver.findElement(By.xpath("//*[@id=\"ui-id-1\"]/div[2]/div/a[1]/span")).click();
		driver.findElement(By.xpath("//*[@id=\"inboxUploadNext\"]/span")).click();
	}
}