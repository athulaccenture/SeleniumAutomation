package Web;
import java.util.concurrent.TimeUnit;


import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.accenture.omnichannelframework.api.OmnichannelFramework;

import adapters.desktop.driver.SeleniumAdapter;

import java.io.File;
import java.io.IOException;  

public class Shot {

	//public static void pic(WebDriver driver, String fileName) throws IOException
	//{
		//System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chromedriver.exe");
		//WebDriver driver=new ChromeDriver();
		

		/*driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
	    File src= ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
  FileUtils.copyFile(src, new File("C:\\selenium\\pic.png"));
  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	public static void main(String[] args) throws IOException {
		
		
  System.out.println("Screenshot Taken");
		// TODO Auto-generated method stub*/

	
	public static void seleniumSaveScreenshot(WebDriver driver, String fileName) {
		try {
			FileUtils.copyFile(((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE),
					new File(OmnichannelFramework.getMediaPath(SeleniumAdapter.ID) + fileName));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}


